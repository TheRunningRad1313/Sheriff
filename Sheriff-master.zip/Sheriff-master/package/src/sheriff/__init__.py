__version__ = '1.6'

def version():
    return __version__

__all__ = ['gui', 'version']