from sheriff import *
import sheriff

# Check Sheriff version -
print(sheriff.version())

# Run the GUI - 
gui.run()